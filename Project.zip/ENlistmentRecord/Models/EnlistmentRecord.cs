
using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class EnlistmentRecord
    {
		[Key]
		public int? EnlistmentId {get;set;}
		public int PersonnelId {get;set;}
		public DateTime EnlistmentStart {get;set;}
		public DateTime EnlistmentEnd {get;set;}
		public int? ContractYears {get;set;}
		public string? Status {get;set;}
		public bool? ReenlistmentFlag {get;set;}
		public string? Remarks {get;set;}
		public DateTime? CreatedAt {get;set;}

    }
}
