
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Models;

namespace ApplicationContexts
{
    public class ApplicationContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=LAPTOP-G6M745HP\\SQLEXPRESS;Database=MonitoringSystem;Trusted_Connection=True;Encrypt=false";
            optionsBuilder.UseSqlServer(connectionString);
            optionsBuilder.EnableSensitiveDataLogging();
            base.OnConfiguring(optionsBuilder);
        }

		public DbSet<ActivityType> ActivityType { get; set; }

		public DbSet<Department> Department { get; set; }

		public DbSet<EnlistmentRecord> EnlistmentRecord { get; set; }

		public DbSet<Personnel> Personnel { get; set; }

		public DbSet<PersonnelActivity> PersonnelActivity { get; set; }

		public DbSet<Rank> Rank { get; set; }

		public DbSet<RankCategory> RankCategory { get; set; }

		public DbSet<Role> Role { get; set; }

		public DbSet<Sidebar> Sidebar { get; set; }

		public DbSet<SidebarRoleMapping> SidebarRoleMapping { get; set; }

		public DbSet<Usertbl> Usertbl { get; set; }

    }
}
